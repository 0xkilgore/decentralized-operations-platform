"use client"

import Home from "../src/app/page"

export default function SyntheticV0PageForDeployment() {
  return <Home />
}